#ifndef UTILS_HPP
#define UTILS_HPP

int compute_last_index(double t, double T, int N);

#endif 