#ifndef COMPUTE_LAST_INDEX_HPP
#define COMPUTE_LAST_INDEX_HPP
#include "utils.hpp"
#include <cmath>

int compute_last_index(double t, double T, int N);

#endif

